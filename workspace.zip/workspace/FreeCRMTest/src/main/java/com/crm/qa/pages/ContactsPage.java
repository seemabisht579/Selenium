package com.crm.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.crm.qa.base.TestBase;

public class ContactsPage extends TestBase {

	@FindBy(xpath="//input[@value='New Contact']")
	WebElement btnNewContact;
	
	@FindBy(name="title")
	WebElement title;
	
	@FindBy(name="first_name")
	WebElement fname;
	
	@FindBy(name="surname")
	WebElement lname;
	
	@FindBy(name="email")
	WebElement email;
	
	@FindBy(xpath="//*[@id='contactForm']/table/tbody/tr[1]/td/input[2]")
	WebElement save;
	
	public ContactsPage(){
		PageFactory.initElements(driver, this);
	}
	
	public void clickBtnNewContacts(){
		btnNewContact.click();
		}
	
	public void fillNewContacts(String ttl, String fn, String ln, String em){
		Select select = new Select(title);
		select.selectByVisibleText(ttl);;
		fname.sendKeys(fn);
		lname.sendKeys(ln);
		email.sendKeys(em);
		save.click();
	}
}
