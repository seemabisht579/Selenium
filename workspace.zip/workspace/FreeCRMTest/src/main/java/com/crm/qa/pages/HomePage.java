package com.crm.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class HomePage extends TestBase {
	
	
	@FindBy(xpath = "//td[contains(text(),'User: Seema Singh')]")
	WebElement userNameLabel;
	
	@FindBy(xpath = "//a[contains(text(),'Contacts')]")
	WebElement contactsLink;
	
	@FindBy(xpath = "//a[contains(text(),'Deals')]")
	WebElement dealsLink;
	
	@FindBy(xpath = "//a[contains(text(),'Tasks')]")
	WebElement tasksLink;
	
	@FindBy(className="fa fa-sign-out icon-2x")
	WebElement logout;
	
	@FindBy(xpath="//*[contains(text(),'New Contact')]")
	WebElement newContact;		
	
	
	//initializing the page objects
	public HomePage(){
		PageFactory.initElements(driver, this);
	}
	
	public String verifyHomePage(){
		return driver.getTitle();
	}
	
	public ContactsPage clickOnContactsLink(){
		contactsLink.click();
		return new ContactsPage();
	}
	
	public boolean verifyUserNameLable(){
		return userNameLabel.isDisplayed();
	}
	
	public TasksPage clickOnTasksLink(){
		tasksLink.click();
		return new TasksPage();
	}
	
	public DealsPage clickOnDealsLink(){
		dealsLink.click();
		return new DealsPage();
	}
	
	public LoginPage logout(){
		logout.click();
		return new LoginPage();
	}
	
	public void clickOnNewContacts(){
		Actions action = new Actions(driver);
		action.moveToElement(contactsLink).build().perform();
		newContact.click();
	}
}
