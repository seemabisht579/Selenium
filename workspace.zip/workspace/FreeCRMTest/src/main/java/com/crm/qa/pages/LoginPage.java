package com.crm.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class LoginPage extends TestBase {

	@FindBy(name="username")
	WebElement uname;
	
	@FindBy(name="password")
	WebElement pswd;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement btnlogin;

	public LoginPage(){
		PageFactory.initElements(driver, this);
	}
	
	public String validatePageTitle(){
		return driver.getTitle();
	}
	
	public HomePage Login(String un, String ps){
		uname.clear();
		pswd.clear();
		uname.sendKeys(un);
		pswd.sendKeys(ps);
		btnlogin.click();
		return new HomePage();
	}
}