package com.crm.qa.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.ContactsPage;
import com.crm.qa.pages.HomePage;
import com.crm.qa.pages.LoginPage;
import com.crm.qa.testutil.TestUtil;

public class ContactsPageTest extends TestBase{

	LoginPage loginPage;
	HomePage homePage;
	ContactsPage contactsPage;
	TestUtil testUtil;
	
	public ContactsPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setup(){
		initialization();
		loginPage = new LoginPage();
		testUtil = new TestUtil();
		homePage = new HomePage();
		//contactPage = new ContactsPage();
		homePage = loginPage.Login(prop.getProperty("username"), prop.getProperty("password"));
		testUtil.switchToFrame();
		homePage.clickOnNewContacts();	
		//contactsPage = homePage.clickOnContactsLink();
	}
	
	/*@Test
	public void clickBtnNewContacts(){
		contactsPage.clickBtnNewContacts();
	}
*/	
	@DataProvider
	public Object[][] getNewContactData(){
		Object data[][] = TestUtil.getTestData("Contacts");
		return data;
		}
	
	@Test(dataProvider = "getNewContactData")
	public void createNewContact(String Title, String FirstName, String LastName, String Email){
	Select select = new Select(driver.findElement(By.name("title")));
	select.selectByVisibleText(Title);
	driver.findElement(By.name("first_name")).sendKeys(FirstName);
	driver.findElement(By.name("surname")).sendKeys(LastName);
	driver.findElement(By.name("email")).sendKeys(Email);
	driver.findElement(By.xpath("//*[@id='contactForm']/table/tbody/tr[1]/td/input[2]")).click();
	}
	
	}

