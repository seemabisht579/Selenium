import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		int n,fact=1;
		System.out.println("Enter a number");
		Scanner obj = new Scanner(System.in);
		n= obj.nextInt();
		System.out.println("number = "+ n);
		int i=n;
		while (i>0){
			fact = fact*i;
			i--;
		}
		System.out.println("Factorial of "+ n + " = " + fact);
	}
}
