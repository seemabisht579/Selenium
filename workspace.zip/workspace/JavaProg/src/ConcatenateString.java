import java.util.Scanner;

public class ConcatenateString {

	public static void main(String[] args) {
		String first,second;
		System.out.println("Enter names");
		Scanner obj= new Scanner(System.in);
		first = obj.nextLine();
		second = obj.nextLine();
		System.out.println("concate names= "+ first.concat(second));

	}

}
