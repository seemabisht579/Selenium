
public class RemoveWhiteSpace {

	public static void main(String[] args) {
		String name="  Seema ";
		System.out.println("Name is "+ name);
		System.out.println("Name is " + name.trim());

	}

}
