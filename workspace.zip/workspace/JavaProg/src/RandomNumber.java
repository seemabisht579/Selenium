import java.util.Random;
import java.util.Scanner;

public class RandomNumber {

	/* public static void main(String[] args) {
		int max;
		Scanner obj= new Scanner(System.in);
		max = obj.nextInt();
		Random ran=new Random();
		for(int i=0;i<=10;i++)
		{
			System.out.println(ran.nextInt(max));
		}
	}  */
	
	public static void main(String args[]){
		
		int max,min;
		Scanner obj= new Scanner(System.in);
		min=obj.nextInt();
		max=obj.nextInt();
		System.out.println("min = "+min);
		System.out.println("max = "+ max);
		Random ran= new Random();
		int value= ran.nextInt(max-min)+max;
		System.out.println(value);
	}

}
