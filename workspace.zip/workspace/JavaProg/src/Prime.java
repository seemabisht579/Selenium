
public class Prime {

	public static void main(String[] args) {
	int n=1987;
	int flag=0;
	for (int i=2;i<=(n/2);i++){
		if(n%i==0 || n%3==0 || n%5==0){
			flag=1;
		}
	}
	if(flag==1){
		System.out.println("Not a prime number");
	}
		else
			System.out.println("prime number");
	}

}
