import java.util.Scanner;

public class ReverseInteger {

	public static void main(String[] args) {
		int num;
		System.out.println("Enter an integer");
		Scanner obj=new Scanner(System.in);
		num = obj.nextInt();
		
		int rev=0,rem=0;
		while (num > 0 ){
		rem = num % 10;
		num = num /10;
		rev = (rev * 10) + rem; }
		System.out.println("Reverse is : "+ rev);
	
	}

}
