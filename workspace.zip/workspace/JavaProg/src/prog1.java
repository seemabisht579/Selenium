/*class prog1 {
public int number;
}

class Test{
public void doIt(int i, prog1 p){
i=5;
p.number=8;
}

public static void main(String args[]){
int x=0;
prog1 p= new prog1();
new Test().doIt(x,p);
System.out.println(x+ " "+p.number);
}
} */



public class prog1{
	public static void badMethod(){
		
	}
	public static void main(String[] args){
		try{
			badMethod();
			System.out.print("A");
		}
		catch(Exception ex){
			System.out.print("B");
		}
		finally{
			System.out.print("C");
		}
		System.out.print("D");
	}
}

