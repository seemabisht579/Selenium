import java.util.Scanner;

public class compareStrings {

	public static void main(String[] args) {
		String a,b;
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter strings");
		a = obj.nextLine();
		System.out.println("First string is : " + a);
		b = obj.nextLine();
		System.out.println("First string is : " + b);
		
		if(a.equalsIgnoreCase(b)){
			System.out.println("Both strings are equals");
					}
		else
			System.out.println("Uneual");
		

	}

}
