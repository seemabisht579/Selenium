import java.util.Scanner;

public class DuplicateChar {

	public static void main(String[] args) {
		String str;
		Scanner obj= new Scanner(System.in);
		System.out.println("Enter string");
		str = obj.nextLine();
		System.out.println("String is : " + str );
		char[] inp= str.toCharArray();
		System.out.print("Duplicate Characters are : ");
		for (int i=0;i<str.length();i++){
			int count=1;
			for (int j=i+1;j<str.length();j++){
				if(inp[i]==inp[j]){
					System.out.println(inp[i]);
					count = count+1;
					//break;
					}
				
			}
				//System.out.println("Duplicate of "+ inp[i] +" is " + count);
				
		}
	}
}
