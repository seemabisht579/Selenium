
public class SwapNumbers {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		System.out.println("Number before swap is :" + a + "and " + b);
		swap(a,b);
		swap1(a,b);
	}


//swap with temporary variable
public static void swap(int a,int b){
	int temp;
	temp = a;
	a = b;
	b = temp; 
	System.out.println("Number after swap is : "+ a + "and " + b);
}

//swap without temporary variable
public static void swap1(int a, int b){
	a=a+b;				//a=30
	b=a-b;				//b=10
	a=a-b;				//a=20
	System.out.println("Number after swap is : "+ a + "and " + b);
}
}