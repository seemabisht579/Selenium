
public class StrToInt {

	public static void main(String[] args) {
		String str="123";
		int i=Integer.parseInt(str);
		System.out.println(str + 50);
		System.out.println(i + 50);
	}

}
