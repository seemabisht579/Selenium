import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		System.out.println("Enter number to find fibonacci");
		Scanner obj = new Scanner(System.in);
		int fib_len = obj.nextInt();
		int num1=0,num2=1;
		int fib;
		System.out.print(num1+","+num2);
		int i=0;
		while(i<fib_len){
			
			fib = num1 + num2;
			System.out.print(","+fib);
			i++;
			num1=num2;
			num2=fib;
		}
	}

}
