import java.util.Scanner;

public class getInputs {

	public static void main(String[] args) {
		int a; 
		float b;
		String c;
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter a string");
		c = obj.nextLine();
		System.out.println("Enter an integer");
		a = obj.nextInt();
		System.out.println("Enter a float");
		b = obj.nextFloat();
	}

}
