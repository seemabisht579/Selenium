import java.util.Scanner;

public class MaxMinArray {

	public static void main(String[] args) {
		
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter the number of element you want in an array");
		int a = obj.nextInt();
		int num[] = new int[a];
		int sum=0;
		
		
		//Enter the number in an array
		for(int i=0;i<a;i++)
		{
			num[i]=obj.nextInt();
			sum=sum+num[i];
		}
		
		//Display array elements
		for(int i=0;i<a;i++)
			{
			System.out.println("number= "+ num[i]);
		}
		System.out.println("sum= "+ sum); 
		
		int max = num[0];
		int min = num[0];
		//find max element
	for(int i=0;i<a;i++){
			if(num[i]>max){
				max=num[i];
			}
			
		}
			System.out.println("Max= "+ max);
		
		//find min element
				for(int i=0;i<a;i++){
					if(num[i]<min){
						min=num[i];
					}
		}
			System.out.println("min= "+ min);
	}
}
