import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PreScreeningAssignment {
	public static void main(String args[]) throws InterruptedException{
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\ravi\\Documents\\chromedriver.exe");
	WebDriver driver= new ChromeDriver();
	driver.get("https://whatfix.com/quickolabs.com/#!flows/how-to-import-google-analytics-solution-of-whatfix/8174f470-9df9-11e3-8178-386077c653fe/");
	driver.manage().window().maximize();
	driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
	driver.findElement(By.className("WFEMG5")).click();
	Thread.sleep(5000);
	driver.switchTo().frame("__gwt_historyFrame");
	
	driver.findElement(By.className("gwt-Anchor WFWIPY")).click();
	driver.findElement(By.id("wfx-dashboard-content-embed")).click();
	driver.findElement(By.id("wfx-dashboard-content-embed-slideshow")).click();
	driver.findElement(By.id("wfx-tooltip-next")).click();
	
	Alert alert = driver.switchTo().alert();
	WebElement popUp = driver.findElement(By.className("WFENAM WFENJ0"));
	if(popUp.equals("Was this flow helpful?")){
		System.out.println("Prescreening is successful");
		}
	else {
		System.out.println("Try again"); }
	
	alert.dismiss();
		
	}
}
