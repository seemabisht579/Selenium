package com.qa.basf.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.basf.testBase.TestBase;

public class HomePage extends TestBase{

	@FindBy(className ="wcms-home-link theme-bg")
	WebElement basfLogo;
	
	
	public HomePage(){
		PageFactory.initElements(driver, this);
	}
	
	public String HomePageTitle(){
		return driver.getTitle();
	}
	
	public WebElement VerifyLogo(){
		return basfLogo;
	}
}
