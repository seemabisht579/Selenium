package com.qa.basf.TestUtil;

import com.qa.basf.testBase.TestBase;

public class TestUtility extends TestBase{

	public static long PAGE_LOAD_TIMEOUT = 70;
	public static long IMPLICIT_WAIT = 80;
	
}
