package com.qa.basf.testPage;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.basf.pages.HomePage;
import com.qa.basf.testBase.TestBase;

public class HomePageTest extends TestBase{

	HomePage homePage;
		
	public HomePageTest(){
		super();
	}
	
	
	@BeforeMethod
	public void LaunchHomePage(){
		Initialization();
		}
	
	@Test(priority=1)
	public void verifyHomePageTitle(){
		String homePageTitle = driver.getTitle();
		System.out.println(driver.getTitle());
		Assert.assertEquals(homePageTitle,prop.getProperty("title"),"wrong title");
		}
	
	@AfterMethod
	public void tearDownBrowser(){
		driver.quit();
	}
}
