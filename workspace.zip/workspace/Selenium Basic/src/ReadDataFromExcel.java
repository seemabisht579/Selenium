import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReadDataFromExcel {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ravi\\Documents\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		
				
		//*[@id="customers"]/tbody/tr[2]/td[1]
		//*[@id="customers"]/tbody/tr[3]/td[1]
		//*[@id="customers"]/tbody/tr[4]/td[1]
		//*[@id="customers"]/tbody/tr[5]/td[1]
		
		//*[@id="customers"]/tbody/tr[2]/td[2]
		//*[@id="customers"]/tbody/tr[2]/td[2]
		//*[@id="customers"]/tbody/tr[2]/td[2]
		
		String beforeXpathCompany = "//*[@id='customers']/tbody/tr[";
		String afterXpathCompany = "]/td[1]";
		
		String beforeXpathContacts = "//*[@id='customers']/tbody/tr[";
		String afterXpathContacts = "]/td[2]";
		
		Thread.sleep(5000);
		List<WebElement> rows= driver.findElements(By.xpath("*//table[@id='customers']//tr"));
		
		for(int i=2;i<=rows.size();i++){
			String actualXpathCompany = beforeXpathCompany + i + afterXpathCompany;
			String companyName = driver.findElement(By.xpath(actualXpathCompany)).getText();
			System.out.println(companyName);
		
			String actualXpathContacts = beforeXpathContacts + i + afterXpathContacts;
			String contacts = driver.findElement(By.xpath(actualXpathContacts)).getText();
			System.out.println(contacts);
		}
		
		
	}

}
