import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrokenLinks {

	public static void main(String args[]) throws MalformedURLException, IOException{
		
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\ravi\\Documents\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
	driver.get("https://www.freecrm.com/index.html");
	
	List<WebElement> list = driver.findElements(By.tagName("a"));
	list.addAll(driver.findElements(By.tagName("img")));
			
	System.out.println("Size of full links & images = " + list.size());
	
	
	List<WebElement> activeLinks = new ArrayList<WebElement>();
	
	for(int i=0;i<list.size();i++){
		System.out.println(list.get(i).getAttribute("href"));
		if(list.get(i).getAttribute("href") == null && (list.get(i).getAttribute("href").contains("javascript"))){
		activeLinks.add(list.get(i));
		//System.out.println(activeLinks.get(i).getText());
		}
	}
	System.out.println("Active links size = "+ activeLinks.size());
	
	for(int j=0;j<activeLinks.size();j++){
		HttpURLConnection url = (HttpURLConnection)new URL(activeLinks.get(j).getAttribute("href")).openConnection();
		url.connect();
		String response = url.getResponseMessage();
		System.out.println(activeLinks.get(j).getAttribute("href")+"---->"+ response);
		url.disconnect();
	}
}}